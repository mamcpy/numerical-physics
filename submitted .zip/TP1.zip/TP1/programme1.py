print("Bonjour")
for i in range(10):
    print("i=", 2*i)